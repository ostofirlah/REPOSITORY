package org.netatlas.monitor;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Локальный VPN, в который направлен ТОЛЬКО трафик к «поддельному» DNS-серверу 10.77.0.2.
 * Весь остальной интернет идёт напрямую. Сервис пересылает DNS-запросы настоящему DNS-серверу
 * сети и запоминает, какое приложение какие адреса запрашивало. На собственные серверы ничего не уходит.
 */
public class NetAtlasVpnService extends VpnService {
    static final String ACTION_START = "org.netatlas.monitor.START";
    static final String ACTION_STOP = "org.netatlas.monitor.STOP";
    static volatile boolean running;

    private static final String TAG = "NetAtlasVpn";
    private static final byte[] DNS_IP = {10, 77, 0, 2};

    private ParcelFileDescriptor tun;
    private FileOutputStream tunOut;
    private final Object outLock = new Object();
    private ExecutorService pool;
    private GeoWorker geo;
    private ConnectivityManager cm;
    private List<InetAddress> upstream = new ArrayList<>();

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            running = false; // поток чтения сам закроет туннель и остановит сервис
            if (tun == null) stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) startVpn();
        return START_NOT_STICKY;
    }

    @Override public void onRevoke() {
        running = false;
    }

    @Override public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    private void startVpn() {
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        upstream = findUpstream(); // обязательно до establish(): потом активной сетью станет сам VPN
        Builder b = new Builder()
                .setSession("Net Atlas")
                .addAddress("10.77.0.1", 32)
                .addDnsServer("10.77.0.2")
                .addRoute("10.77.0.2", 32)
                .setMtu(1500)
                .setBlocking(true);
        try {
            b.addDisallowedApplication(getPackageName()); // собственный трафик (геолокация, карта) идёт мимо VPN
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        try {
            tun = b.establish();
        } catch (Exception e) {
            Log.e(TAG, "establish failed", e);
        }
        if (tun == null) {
            stopSelf();
            return;
        }
        tunOut = new FileOutputStream(tun.getFileDescriptor());
        SharedPreferences sp = getSharedPreferences("netatlas", MODE_PRIVATE);
        Store.geoEnabled = sp.getBoolean("geo", true);
        pool = Executors.newFixedThreadPool(6);
        geo = new GeoWorker();
        geo.start();
        running = true;
        final FileInputStream in = new FileInputStream(tun.getFileDescriptor());
        new Thread(() -> readLoop(in), "netatlas-reader").start();
    }

    private void readLoop(FileInputStream in) {
        byte[] buf = new byte[32768];
        StructPollfd[] fds = {new StructPollfd()};
        fds[0].fd = tun.getFileDescriptor();
        fds[0].events = (short) OsConstants.POLLIN;
        try {
            while (running) {
                int r;
                try {
                    r = Os.poll(fds, 500);
                } catch (ErrnoException e) {
                    if (e.errno == OsConstants.EINTR) continue;
                    break;
                }
                if (r <= 0) continue;
                int ev = fds[0].revents;
                if ((ev & (OsConstants.POLLERR | OsConstants.POLLHUP | OsConstants.POLLNVAL)) != 0) break;
                if ((ev & OsConstants.POLLIN) == 0) continue;
                int n = in.read(buf);
                if (n < 0) break;
                if (n == 0) continue;
                IpPackets.Udp u = IpPackets.parseUdp(buf, n);
                if (u == null || u.dstPort != 53 || !Arrays.equals(u.dst, DNS_IP)) continue;
                final byte[] query = Arrays.copyOfRange(buf, u.offset, u.offset + u.length);
                final byte[] srcIp = u.src;
                final int srcPort = u.srcPort;
                pool.execute(() -> handleQuery(query, srcIp, srcPort));
            }
        } catch (IOException | RuntimeException e) {
            Log.w(TAG, "read loop ended", e);
        } finally {
            shutdown();
        }
    }

    private void shutdown() {
        running = false;
        if (geo != null) geo.interrupt();
        if (pool != null) pool.shutdownNow();
        try {
            if (tun != null) tun.close();
        } catch (IOException ignored) {
        }
        tun = null;
        stopSelf();
    }

    private void handleQuery(byte[] query, byte[] srcIp, int srcPort) {
        try {
            Store.countQuery();
            String qname = Dns.queryName(query);
            int uid = ownerUid(srcIp, srcPort);
            byte[] resp = forward(query);
            if (resp == null) resp = Dns.servfail(query);
            if (resp == null) return;
            String key = keyFor(uid);
            for (InetAddress a : Dns.addresses(resp)) {
                Store.record(key, qname, a.getHostAddress());
            }
            byte[] pkt = IpPackets.buildUdp(DNS_IP, 53, srcIp, srcPort, resp);
            synchronized (outLock) {
                if (tunOut != null) tunOut.write(pkt);
            }
        } catch (IOException | RuntimeException e) {
            Log.w(TAG, "dns handling failed", e);
        }
    }

    /** UID приложения, приславшего DNS-запрос (Android 10+, разрешено владельцу VPN). */
    private int ownerUid(byte[] srcIp, int srcPort) {
        try {
            InetSocketAddress local = new InetSocketAddress(InetAddress.getByAddress(srcIp), srcPort);
            InetSocketAddress remote = new InetSocketAddress(InetAddress.getByAddress(DNS_IP), 53);
            return cm.getConnectionOwnerUid(OsConstants.IPPROTO_UDP, local, remote);
        } catch (Exception e) {
            return -1;
        }
    }

    private String keyFor(int uid) {
        if (uid < 0) return "uid:?";
        String[] names = getPackageManager().getPackagesForUid(uid);
        if (names != null && names.length > 0) return names[0];
        return "uid:" + uid;
    }

    private byte[] forward(byte[] q) {
        int tries = Math.min(2, upstream.size());
        for (int i = 0; i < tries; i++) {
            DatagramSocket s = null;
            try {
                s = new DatagramSocket();
                protect(s); // в обход нашего же VPN
                s.setSoTimeout(3000);
                s.connect(new InetSocketAddress(upstream.get(i), 53));
                s.send(new DatagramPacket(q, q.length));
                byte[] r = new byte[8192];
                DatagramPacket p = new DatagramPacket(r, r.length);
                s.receive(p);
                if (p.getLength() >= 2 && r[0] == q[0] && r[1] == q[1]) return Arrays.copyOf(r, p.getLength());
            } catch (IOException ignored) {
            } finally {
                if (s != null) s.close();
            }
        }
        return null;
    }

    private List<InetAddress> findUpstream() {
        List<InetAddress> out = new ArrayList<>();
        try {
            Network n = cm.getActiveNetwork();
            LinkProperties lp = n == null ? null : cm.getLinkProperties(n);
            if (lp != null) out.addAll(lp.getDnsServers());
        } catch (RuntimeException ignored) {
        }
        if (out.isEmpty()) {
            try {
                out.add(InetAddress.getByAddress(new byte[]{1, 1, 1, 1}));
            } catch (IOException ignored) {
            }
        }
        return out;
    }
}
