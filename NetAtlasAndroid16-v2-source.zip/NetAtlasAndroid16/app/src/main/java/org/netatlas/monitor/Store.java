package org.netatlas.monitor;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Хранилище в памяти: куда обращались приложения и где эти адреса находятся. */
final class Store {
    static final class Dest {
        final String host, ip;
        final long last;
        final int hits;
        Dest(String host, String ip, long last, int hits) {
            this.host = host; this.ip = ip; this.last = last; this.hits = hits;
        }
    }

    static final class Geo {
        final String cc;
        final double lat, lon;
        Geo(String cc, double lat, double lon) { this.cc = cc; this.lat = lat; this.lon = lon; }
    }

    static volatile boolean geoEnabled = true;

    private static final int MAX_PER_APP = 400;
    private static final long RETRY_MS = 10 * 60 * 1000L;
    private static final Object LOCK = new Object();
    private static final Map<String, LinkedHashMap<String, Dest>> apps = new HashMap<>();
    private static final Map<String, Geo> geo = new HashMap<>();
    private static final Map<String, Long> failed = new HashMap<>();
    private static int version, queries;

    private Store() {}

    static int version() { synchronized (LOCK) { return version; } }
    static int queries() { synchronized (LOCK) { return queries; } }
    static void countQuery() { synchronized (LOCK) { queries++; } }

    static void record(String pkg, String host, String ip) {
        long now = System.currentTimeMillis();
        synchronized (LOCK) {
            LinkedHashMap<String, Dest> m = apps.get(pkg);
            if (m == null) { m = new LinkedHashMap<>(); apps.put(pkg, m); }
            Dest old = m.remove(ip);
            int hits = old == null ? 1 : old.hits + 1;
            String h = host != null ? host : (old != null ? old.host : ip);
            m.put(ip, new Dest(h, ip, now, hits));
            if (m.size() > MAX_PER_APP) {
                Iterator<String> it = m.keySet().iterator();
                it.next();
                it.remove();
            }
            version++;
        }
    }

    static Map<String, List<Dest>> allDests() {
        Map<String, List<Dest>> out = new HashMap<>();
        synchronized (LOCK) {
            for (Map.Entry<String, LinkedHashMap<String, Dest>> e : apps.entrySet()) {
                List<Dest> l = new ArrayList<>(e.getValue().values());
                Collections.reverse(l); // свежие первыми
                out.put(e.getKey(), l);
            }
        }
        return out;
    }

    static int totalDests() {
        int n = 0;
        synchronized (LOCK) { for (LinkedHashMap<String, Dest> m : apps.values()) n += m.size(); }
        return n;
    }

    static Geo geo(String ip) { synchronized (LOCK) { return geo.get(ip); } }

    static void putGeo(String ip, Geo g) {
        synchronized (LOCK) { geo.put(ip, g); version++; }
    }

    static void markGeoFailed(String ip) {
        synchronized (LOCK) { failed.put(ip, System.currentTimeMillis()); }
    }

    /** Публичные адреса, для которых ещё нет геоданных. */
    static List<String> pendingGeo(int max) {
        Set<String> out = new HashSet<>();
        long now = System.currentTimeMillis();
        synchronized (LOCK) {
            for (LinkedHashMap<String, Dest> m : apps.values()) {
                for (String ip : m.keySet()) {
                    if (out.size() >= max) break;
                    if (geo.containsKey(ip)) continue;
                    Long f = failed.get(ip);
                    if (f != null && now - f < RETRY_MS) continue;
                    if (isPublic(ip)) out.add(ip);
                }
            }
        }
        return new ArrayList<>(out);
    }

    static void clear() {
        synchronized (LOCK) { apps.clear(); queries = 0; version++; }
    }

    static boolean isPublic(String ip) {
        try {
            InetAddress a = InetAddress.getByName(ip); // литерал, DNS не вызывается
            if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress()
                    || a.isSiteLocalAddress() || a.isMulticastAddress()) return false;
            byte[] b = a.getAddress();
            if (b.length == 4 && (b[0] & 0xff) == 100 && (b[1] & 0xc0) == 64) return false; // CGNAT
            if (b.length == 16 && (b[0] & 0xfe) == 0xfc) return false; // ULA
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
