package org.netatlas.monitor;

import java.util.concurrent.atomic.AtomicInteger;

/** Минимальный разбор и сборка IPv4/UDP-пакетов (без зависимостей от Android). */
final class IpPackets {
    private static final AtomicInteger IDENT = new AtomicInteger((int) (System.nanoTime() & 0x7fff));

    private IpPackets() {}

    static final class Udp {
        final byte[] src = new byte[4];
        final byte[] dst = new byte[4];
        int srcPort, dstPort;
        int offset, length; // полезная нагрузка внутри исходного буфера
    }

    /** Возвращает null, если это не целый IPv4/UDP-пакет. */
    static Udp parseUdp(byte[] b, int len) {
        if (len < 28 || (b[0] >> 4) != 4) return null;
        int ihl = (b[0] & 0x0f) * 4;
        if (ihl < 20 || len < ihl + 8) return null;
        if ((b[9] & 0xff) != 17) return null;
        boolean moreFragments = (b[6] & 0x20) != 0;
        int fragOffset = ((b[6] & 0x1f) << 8) | (b[7] & 0xff);
        if (moreFragments || fragOffset != 0) return null;
        int total = u16(b, 2);
        if (total > len || total < ihl + 8) return null;
        int udpLen = u16(b, ihl + 4);
        if (udpLen < 8 || ihl + udpLen > total) return null;
        Udp u = new Udp();
        System.arraycopy(b, 12, u.src, 0, 4);
        System.arraycopy(b, 16, u.dst, 0, 4);
        u.srcPort = u16(b, ihl);
        u.dstPort = u16(b, ihl + 2);
        u.offset = ihl + 8;
        u.length = udpLen - 8;
        return u;
    }

    static byte[] buildUdp(byte[] src, int srcPort, byte[] dst, int dstPort, byte[] payload) {
        int udpLen = 8 + payload.length;
        int total = 20 + udpLen;
        byte[] p = new byte[total];
        p[0] = 0x45;
        put16(p, 2, total);
        put16(p, 4, IDENT.incrementAndGet() & 0xffff);
        put16(p, 6, 0x4000);
        p[8] = 64;
        p[9] = 17;
        System.arraycopy(src, 0, p, 12, 4);
        System.arraycopy(dst, 0, p, 16, 4);
        put16(p, 10, checksum(p, 0, 20, 0));
        put16(p, 20, srcPort);
        put16(p, 22, dstPort);
        put16(p, 24, udpLen);
        System.arraycopy(payload, 0, p, 28, payload.length);
        int pseudo = u16(src, 0) + u16(src, 2) + u16(dst, 0) + u16(dst, 2) + 17 + udpLen;
        int cs = checksum(p, 20, udpLen, pseudo);
        put16(p, 26, cs == 0 ? 0xffff : cs);
        return p;
    }

    static int checksum(byte[] d, int off, int len, int initial) {
        long sum = initial & 0xffffffffL;
        int i = off, end = off + len;
        while (i + 1 < end) {
            sum += ((d[i] & 0xff) << 8) | (d[i + 1] & 0xff);
            i += 2;
        }
        if (i < end) sum += (d[i] & 0xff) << 8;
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        return (int) (~sum & 0xffff);
    }

    static int u16(byte[] b, int o) { return ((b[o] & 0xff) << 8) | (b[o + 1] & 0xff); }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) (v >> 8);
        b[o + 1] = (byte) v;
    }
}
