package org.netatlas.monitor;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 41, REQ_VPN = 42;
    private static final int DARK = Color.rgb(17, 24, 39);

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Map<String, String> labels = new HashMap<>();
    private final Set<String> expanded = new HashSet<>();
    private final List<AppItem> apps = new ArrayList<>();

    private LinearLayout root, content, listLayout;
    private ScrollView listScroll;
    private Button vpnBtn, mapTab, listTab;
    private CheckBox geoBox;
    private TextView status, filterBar;
    private WebView map;
    private boolean mapReady, showingMap = true;
    private double devLat = Double.NaN, devLon = Double.NaN;
    private String filterPkg;
    private int lastVersion = -1;
    private LocationManager locationManager;
    private LocationListener locationListener;

    private static final class AppItem {
        final String pkg, label;
        AppItem(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    private static final class Row {
        final String pkg, label;
        final List<Store.Dest> dests;
        Row(String pkg, String label, List<Store.Dest> dests) { this.pkg = pkg; this.label = label; this.dests = dests; }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Store.geoEnabled = prefs().getBoolean("geo", true);
        buildShell();
        showMap();
        requestLocationIfNeeded();
    }

    @Override protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override protected void onPause() {
        ui.removeCallbacks(tick);
        super.onPause();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateControls();
            int v = Store.version();
            if (v != lastVersion) {
                lastVersion = v;
                if (showingMap) pushMapState(); else refreshList();
            }
            ui.postDelayed(this, 1500);
        }
    };

    // ---------------------------------------------------------------- интерфейс

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(DARK);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsets.CONSUMED;
        });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(12), dp(18), dp(10));
        header.addView(text("NET ATLAS", 21, Color.WHITE, true));
        header.addView(text("Куда обращаются приложения · Android 16", 12, Color.rgb(203, 213, 225), false));
        root.addView(header);

        LinearLayout tabs = row(Color.WHITE);
        mapTab = button("MAP");
        mapTab.setOnClickListener(v -> showMap());
        listTab = button("LIST");
        listTab.setOnClickListener(v -> showApps());
        tabs.addView(mapTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        tabs.addView(listTab, new LinearLayout.LayoutParams(0, dp(44), 1));
        root.addView(tabs);

        LinearLayout controls = row(Color.rgb(243, 244, 246));
        vpnBtn = button("");
        vpnBtn.setOnClickListener(v -> toggleVpn());
        controls.addView(vpnBtn, new LinearLayout.LayoutParams(0, dp(44), 1));
        geoBox = new CheckBox(this);
        geoBox.setText("Страна по IP");
        geoBox.setTextSize(12);
        geoBox.setChecked(Store.geoEnabled);
        geoBox.setOnCheckedChangeListener((b, on) -> {
            Store.geoEnabled = on;
            prefs().edit().putBoolean("geo", on).apply();
        });
        controls.addView(geoBox, new LinearLayout.LayoutParams(-2, dp(44)));
        root.addView(controls);

        status = text("", 12, Color.rgb(124, 45, 18), false);
        status.setPadding(dp(14), dp(8), dp(14), dp(8));
        status.setBackgroundColor(Color.rgb(255, 247, 237));
        root.addView(status);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundColor(Color.rgb(245, 247, 250));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        updateControls();
    }

    private void updateControls() {
        boolean on = NetAtlasVpnService.running;
        vpnBtn.setText(on ? "■ Остановить мониторинг" : "▶ Начать мониторинг");
        status.setText(on
                ? "Мониторинг включён · DNS-запросов: " + Store.queries() + " · серверов: " + Store.totalDests()
                  + "\nВидны адреса, которые приложения запрашивают через DNS."
                : "Мониторинг выключен. Нажмите «Начать» и дайте разрешение на локальный VPN: он ничего не отправляет на серверы приложения.");
        setTabStyle(mapTab, showingMap);
        setTabStyle(listTab, !showingMap);
    }

    private void showMap() {
        showingMap = true;
        content.removeAllViews();
        listLayout = null;
        listScroll = null;
        ensureMap();
        if (filterPkg != null) {
            filterBar = text("Фильтр: " + labelFor(filterPkg) + "   ✕ показать все", 12, Color.WHITE, true);
            filterBar.setBackgroundColor(Color.rgb(37, 99, 235));
            filterBar.setPadding(dp(14), dp(8), dp(14), dp(8));
            filterBar.setOnClickListener(v -> { filterPkg = null; showMap(); });
            content.addView(filterBar);
        }
        if (map.getParent() != null) ((ViewGroup) map.getParent()).removeView(map);
        content.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));
        updateControls();
        pushMapState();
    }

    private void showApps() {
        showingMap = false;
        content.removeAllViews();
        loadApps();
        TextView intro = text("ПРИЛОЖЕНИЯ НА УСТРОЙСТВЕ", 14, Color.rgb(31, 41, 55), true);
        intro.setPadding(dp(16), dp(12), dp(16), dp(6));
        content.addView(intro);
        listScroll = new ScrollView(this);
        listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);
        listLayout.setPadding(dp(12), 0, dp(12), dp(12));
        listScroll.addView(listLayout);
        content.addView(listScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        updateControls();
        refreshList();
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        try {
            for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                if (ai.packageName.equals(getPackageName())) continue;
                if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue; // только приложения с иконкой
                apps.add(new AppItem(ai.packageName, String.valueOf(pm.getApplicationLabel(ai))));
            }
        } catch (RuntimeException e) {
            status.setText("Не удалось прочитать список приложений: " + e.getMessage());
        }
    }

    private void refreshList() {
        if (listLayout == null || listScroll == null) return;
        final int scrollY = listScroll.getScrollY();
        listLayout.removeAllViews();
        Map<String, List<Store.Dest>> all = Store.allDests();
        List<Row> rows = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (AppItem a : apps) {
            rows.add(new Row(a.pkg, a.label, all.get(a.pkg)));
            seen.add(a.pkg);
        }
        for (Map.Entry<String, List<Store.Dest>> e : all.entrySet()) {
            if (!seen.contains(e.getKey())) rows.add(new Row(e.getKey(), labelFor(e.getKey()), e.getValue()));
        }
        Collections.sort(rows, (x, y) -> {
            int cx = x.dests == null ? 0 : x.dests.size();
            int cy = y.dests == null ? 0 : y.dests.size();
            if (cx != cy) return cy - cx;
            return x.label.compareToIgnoreCase(y.label);
        });
        for (Row r : rows) listLayout.addView(card(r));
        listScroll.post(() -> listScroll.scrollTo(0, scrollY));
    }

    private View card(final Row r) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        card.setLayoutParams(lp);
        card.addView(text(r.label, 15, Color.rgb(17, 24, 39), true));
        card.addView(text(r.pkg, 11, Color.rgb(107, 114, 128), false));
        int n = r.dests == null ? 0 : r.dests.size();
        if (n > 0) {
            Set<String> countries = new TreeSet<>();
            for (Store.Dest d : r.dests) {
                Store.Geo g = Store.geo(d.ip);
                if (g != null) countries.add(g.cc);
            }
            card.addView(text("Серверов: " + n + (countries.isEmpty() ? "" : " · страны: " + join(countries)),
                    12, Color.rgb(37, 99, 235), false));
            card.setOnClickListener(v -> {
                if (!expanded.remove(r.pkg)) expanded.add(r.pkg);
                refreshList();
            });
            if (expanded.contains(r.pkg)) {
                int shown = 0;
                for (Store.Dest d : r.dests) {
                    if (shown++ >= 40) break;
                    Store.Geo g = Store.geo(d.ip);
                    TextView t = text(d.host + "\n" + d.ip + (g != null ? "  ·  " + g.cc : ""), 11, Color.rgb(55, 65, 81), false);
                    t.setPadding(0, dp(5), 0, 0);
                    card.addView(t);
                }
                Button show = button("Показать на карте");
                show.setOnClickListener(v -> { filterPkg = r.pkg; showMap(); });
                card.addView(show, new LinearLayout.LayoutParams(-1, dp(44)));
            }
        } else {
            card.addView(text("нет данных", 11, Color.rgb(156, 163, 175), false));
        }
        return card;
    }

    private static String join(Set<String> s) {
        StringBuilder sb = new StringBuilder();
        for (String x : s) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(x);
        }
        return sb.toString();
    }

    // -------------------------------------------------------------------- карта

    private void ensureMap() {
        if (map != null) return;
        map = new WebView(this);
        WebSettings s = map.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " NetAtlas/0.2");
        map.setWebChromeClient(new WebChromeClient());
        map.setWebViewClient(new WebViewClient());
        map.addJavascriptInterface(new MapBridge(), "AndroidBridge");
        // HTTPS-адрес нужен, чтобы тайлы OpenStreetMap получали корректный Referer
        map.loadDataWithBaseURL("https://netatlas.local/", readAsset("map.html"), "text/html", "UTF-8", null);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (IOException e) {
            return "<html><body>map.html missing</body></html>";
        }
    }

    private void pushMapState() {
        if (map == null || !mapReady) return;
        if (!Double.isNaN(devLat)) {
            map.evaluateJavascript(String.format(Locale.US, "window.setDeviceLocation(%.6f,%.6f)", devLat, devLon), null);
        }
        try {
            JSONArray arr = new JSONArray();
            Map<String, List<Store.Dest>> all = Store.allDests();
            for (Map.Entry<String, List<Store.Dest>> e : all.entrySet()) {
                if (filterPkg != null && !filterPkg.equals(e.getKey())) continue;
                String label = labelFor(e.getKey());
                for (Store.Dest d : e.getValue()) {
                    Store.Geo g = Store.geo(d.ip);
                    if (g == null) continue;
                    if (arr.length() >= 300) break;
                    JSONObject o = new JSONObject();
                    o.put("a", label);
                    o.put("h", d.host);
                    o.put("ip", d.ip);
                    o.put("cc", g.cc);
                    o.put("lat", g.lat);
                    o.put("lon", g.lon);
                    o.put("n", d.hits);
                    arr.put(o);
                }
            }
            map.evaluateJavascript("window.setDestinations(" + arr.toString() + ")", null);
        } catch (JSONException ignored) {
        }
    }

    private class MapBridge {
        @JavascriptInterface public void mapReady() {
            runOnUiThread(() -> {
                mapReady = true;
                pushMapState();
            });
        }
    }

    // ---------------------------------------------------------------------- VPN

    private void toggleVpn() {
        if (NetAtlasVpnService.running) {
            startService(new Intent(this, NetAtlasVpnService.class).setAction(NetAtlasVpnService.ACTION_STOP));
            return;
        }
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            startActivityForResult(consent, REQ_VPN);
        } else {
            startVpnService();
        }
    }

    private void startVpnService() {
        startService(new Intent(this, NetAtlasVpnService.class).setAction(NetAtlasVpnService.ACTION_START));
        ui.postDelayed(this::updateControls, 600);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) startVpnService();
    }

    // ------------------------------------------------------------- геолокация

    private void requestLocationIfNeeded() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : locationManager.getProviders(true)) {
                try {
                    Location l = locationManager.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (SecurityException ignored) {
                }
            }
            if (best != null) onLocation(best);
            locationListener = new LocationListener() {
                @Override public void onLocationChanged(Location l) { onLocation(l); }
                @Override public void onProviderEnabled(String p) { }
                @Override public void onProviderDisabled(String p) { }
                @Override public void onStatusChanged(String p, int s, Bundle b) { }
            };
            for (String p : locationManager.getProviders(true)) {
                try {
                    locationManager.requestLocationUpdates(p, 15000, 25, locationListener);
                } catch (RuntimeException ignored) {
                }
            }
        } catch (RuntimeException ignored) {
        }
    }

    private void onLocation(Location l) {
        devLat = l.getLatitude();
        devLon = l.getLongitude();
        runOnUiThread(() -> {
            if (map != null && mapReady) {
                map.evaluateJavascript(String.format(Locale.US, "window.setDeviceLocation(%.6f,%.6f)", devLat, devLon), null);
            }
        });
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOCATION) {
            for (int r : results) {
                if (r == PackageManager.PERMISSION_GRANTED) { requestLocationIfNeeded(); return; }
            }
        }
    }

    @Override protected void onDestroy() {
        if (locationManager != null && locationListener != null) {
            try { locationManager.removeUpdates(locationListener); } catch (RuntimeException ignored) { }
        }
        if (map != null) map.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ утилиты

    private String labelFor(String key) {
        String cached = labels.get(key);
        if (cached != null) return cached;
        String out;
        if (key.startsWith("uid:")) {
            out = "Система / не определено (" + key + ")";
        } else {
            try {
                PackageManager pm = getPackageManager();
                out = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(key, 0)));
            } catch (PackageManager.NameNotFoundException e) {
                out = key;
            }
        }
        labels.put(key, out);
        return out;
    }

    private SharedPreferences prefs() { return getSharedPreferences("netatlas", MODE_PRIVATE); }

    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }

    private LinearLayout row(int bg) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setPadding(dp(12), dp(6), dp(12), dp(6));
        l.setBackgroundColor(bg);
        return l;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setAllCaps(false);
        return b;
    }

    private void setTabStyle(Button b, boolean selected) {
        b.setBackgroundColor(selected ? DARK : Color.rgb(229, 231, 235));
        b.setTextColor(selected ? Color.WHITE : Color.rgb(31, 41, 55));
    }
}
