package org.netatlas.monitor;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/** Определяет страну и примерные координаты IP через get.geojs.io (HTTPS). */
final class GeoWorker extends Thread {
    GeoWorker() {
        super("netatlas-geo");
        setDaemon(true);
    }

    @Override public void run() {
        while (!isInterrupted()) {
            try {
                List<String> ips = Store.geoEnabled ? Store.pendingGeo(5) : null;
                if (ips == null || ips.isEmpty()) { Thread.sleep(2000); continue; }
                for (String ip : ips) {
                    lookup(ip);
                    Thread.sleep(250);
                }
            } catch (InterruptedException e) {
                return;
            } catch (Exception ignored) {
            }
        }
    }

    private void lookup(String ip) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://get.geojs.io/v1/ip/geo/" + ip + ".json").openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setRequestProperty("User-Agent", "NetAtlas/0.2");
            if (c.getResponseCode() != 200) { Store.markGeoFailed(ip); return; }
            Store.Geo g = parse(readLimited(c.getInputStream(), 16384));
            if (g == null) Store.markGeoFailed(ip); else Store.putGeo(ip, g);
        } catch (IOException | JSONException e) {
            Store.markGeoFailed(ip);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String readLimited(InputStream in, int max) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        int n;
        while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    /** Терпимый к формату разбор: числа могут быть строками, поля называться по-разному. */
    static Store.Geo parse(String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        double lat = num(o, "latitude", "lat");
        double lon = num(o, "longitude", "lng", "lon");
        if (Double.isNaN(lat) || Double.isNaN(lon)) return null;
        String cc = o.optString("country_code", "");
        if (cc.isEmpty()) {
            JSONObject co = o.optJSONObject("country");
            if (co != null) cc = co.optString("code", "");
        }
        return new Store.Geo(cc.isEmpty() ? "??" : cc, lat, lon);
    }

    private static double num(JSONObject o, String... keys) {
        for (String k : keys) {
            Object v = o.opt(k);
            if (v instanceof Number) return ((Number) v).doubleValue();
            if (v instanceof String) {
                try { return Double.parseDouble((String) v); } catch (NumberFormatException ignored) { }
            }
        }
        return Double.NaN;
    }
}
