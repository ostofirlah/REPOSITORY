package org.netatlas.monitor;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Разбор DNS-сообщений (без зависимостей от Android). */
final class Dns {
    private Dns() {}

    /** Имя из первого вопроса или null. */
    static String queryName(byte[] m) {
        if (m.length < 12 || u16(m, 4) < 1) return null;
        return readName(m, new int[]{12});
    }

    /** Все A/AAAA-адреса из ответа. */
    static List<InetAddress> addresses(byte[] m) {
        List<InetAddress> out = new ArrayList<>();
        if (m.length < 12) return out;
        int qd = u16(m, 4), an = u16(m, 6);
        int[] pos = {12};
        for (int i = 0; i < qd; i++) {
            if (readName(m, pos) == null) return out;
            pos[0] += 4;
            if (pos[0] > m.length) return out;
        }
        for (int i = 0; i < an; i++) {
            if (readName(m, pos) == null) break;
            int p = pos[0];
            if (p + 10 > m.length) break;
            int type = u16(m, p);
            int rdlen = u16(m, p + 8);
            p += 10;
            if (p + rdlen > m.length) break;
            if ((type == 1 && rdlen == 4) || (type == 28 && rdlen == 16)) {
                try {
                    out.add(InetAddress.getByAddress(Arrays.copyOfRange(m, p, p + rdlen)));
                } catch (UnknownHostException ignored) {
                }
            }
            pos[0] = p + rdlen;
        }
        return out;
    }

    /** Ответ SERVFAIL на запрос (чтобы клиент не ждал таймаута). */
    static byte[] servfail(byte[] m) {
        if (m.length < 12 || u16(m, 4) < 1) return null;
        int[] pos = {12};
        if (readName(m, pos) == null) return null;
        int end = pos[0] + 4;
        if (end > m.length) return null;
        byte[] r = Arrays.copyOf(m, end);
        r[2] = (byte) (0x80 | (m[2] & 0x79));
        r[3] = (byte) 0x82;
        r[4] = 0; r[5] = 1;
        for (int i = 6; i < 12; i++) r[i] = 0;
        return r;
    }

    private static int u16(byte[] m, int o) { return ((m[o] & 0xff) << 8) | (m[o + 1] & 0xff); }

    /** Читает имя (с поддержкой сжатия), сдвигает pos[0] за имя. null при ошибке. */
    private static String readName(byte[] m, int[] pos) {
        StringBuilder sb = new StringBuilder();
        int p = pos[0], jumps = 0, endPos = -1;
        boolean jumped = false;
        while (true) {
            if (p >= m.length) return null;
            int l = m[p] & 0xff;
            if (l == 0) { p++; break; }
            if ((l & 0xc0) == 0xc0) {
                if (p + 1 >= m.length) return null;
                int ptr = ((l & 0x3f) << 8) | (m[p + 1] & 0xff);
                if (!jumped) { endPos = p + 2; jumped = true; }
                if (++jumps > 32 || ptr >= m.length) return null;
                p = ptr;
                continue;
            }
            if ((l & 0xc0) != 0) return null;
            p++;
            if (p + l > m.length) return null;
            if (sb.length() > 0) sb.append('.');
            for (int i = 0; i < l; i++) {
                char c = (char) (m[p + i] & 0xff);
                sb.append(c >= 0x20 && c < 0x7f ? Character.toLowerCase(c) : '?');
            }
            p += l;
            if (sb.length() > 253) return null;
        }
        pos[0] = jumped ? endPos : p;
        return sb.toString();
    }
}
